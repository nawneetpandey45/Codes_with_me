// script.js for INC Innovation Center Clone
console.log('INC Innovation Center UI loaded.');
